$Id: readme.txt 3900 2010-11-17 03:59:50Z unsaved $

Each subdirectory of this directory is a home directory to a sample integration
application.

See the "readme.txt" file in each subdirectory to see the purpose of that
particular sample.
